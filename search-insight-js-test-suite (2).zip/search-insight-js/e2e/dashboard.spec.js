const { test, expect } = require("@playwright/test");

// UI実装後に baseURL と画面要素を実際のアプリに合わせて設定してください。
// このテストは現時点ではUI未実装のため、実行対象ではなく接続用の雛形です。
test.skip("ダッシュボードにキーワード別の縦棒グラフを表示する", async ({ page }) => {
  await page.goto("/");
  await expect(page.getByRole("heading", { name: /分析ダッシュボード/ })).toBeVisible();
  await expect(page.locator("canvas[data-chart='keyword-frequency']")).toBeVisible();
});

test.skip("期間を変更するとグラフが更新される", async ({ page }) => {
  await page.goto("/");
  await page.getByLabel("集計期間").selectOption("3months");
  await expect(page.locator("canvas[data-chart='keyword-frequency']")).toBeVisible();
});
