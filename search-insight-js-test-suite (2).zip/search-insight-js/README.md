# Search Insight JS — 全体テスト基盤

JavaScript中心の検索履歴分析アプリ向け、実行可能なテスト基盤です。

## 含まれるもの
- 検索URLからのキーワード抽出（Google / Bing / Yahoo! Japan）
- 履歴データの正規化・重複排除・JSONインポート
- 長期時系列集計
- テーマ分類・キーワード関連性集計
- 心理的傾向の慎重な仮説生成（診断は禁止）
- 縦棒グラフ用データ生成（Chart.js等に接続可能）
- 同意確認・ユーザー単位の保存・削除
- Chrome History APIアダプターのモックテスト
- Playwright用のE2Eテスト雛形

## 実行方法
Node.js 20以上を用意し、プロジェクトフォルダーで:

```bash
npm test
```

PlaywrightのE2Eテストを使う場合:

```bash
npm install
npx playwright install
npm run test:e2e
```

## 重要な前提
これはテスト可能な最小実装とテスト基盤です。実際のChrome拡張、AI API、UI、認証、クラウド保存はまだ接続していません。
Chrome履歴の取得は、利用者が拡張機能の権限とアクセスを明示的に許可した場合に限る設計です。
Google Takeoutの全形式・全データを完全に取り込めることを保証しません。現時点のインポート形式は本プロジェクトで定義したJSON形式です。

心理分析は検索行動から作る仮説に限定します。精神疾患、人格、思想、宗教、政治的立場、性的指向などを推定・診断する機能は実装しません。
検索語だけで本人の本心や生活状況を断定しないこと。レポートでは根拠・代替解釈・確信度を表示してください。

## 履歴JSON形式
```json
[
  {
    "url": "https://www.google.com/search?q=引っ越し+初期費用",
    "timestamp": "2026-01-12T09:30:00.000Z",
    "source": "google"
  }
]
```

## テストの範囲と未検証事項
- `npm test`: ローカルのロジック、境界値、異常系を検証
- Playwright: UI実装後に接続するE2E雛形
- Chrome実機での権限確認、Google Takeout実データとの互換性、AIモデルの妥当性、実環境のセキュリティ診断は未実施
