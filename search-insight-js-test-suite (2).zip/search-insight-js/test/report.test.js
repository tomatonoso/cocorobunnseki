const test = require("node:test");
const assert = require("node:assert/strict");
const { createReport } = require("../src/report");

test("総合レポートに全主要セクションを含む", () => {
  const report = createReport([
    { keyword: "転職 方法", timestamp: "2026-01-01T00:00:00Z" },
    { keyword: "転職 比較", timestamp: "2026-02-01T00:00:00Z" }
  ]);
  for (const key of [
    "totalSearches", "topKeywords", "timeline", "keywordAssociations",
    "keywordChart", "themeChart", "psychologicalHypotheses", "limitations"
  ]) assert.ok(Object.hasOwn(report, key), `${key}が必要`);
  assert.equal(report.totalSearches, 2);
});
test("空データでも総合レポートを生成", () => {
  const report = createReport([]);
  assert.equal(report.totalSearches, 0);
  assert.deepEqual(report.topKeywords, []);
});
test("不正入力を拒否", () => {
  assert.throws(() => createReport(null), /配列/);
});
