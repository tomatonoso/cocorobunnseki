const test = require("node:test");
const assert = require("node:assert/strict");
const { createChromeHistoryAdapter } = require("../src/chrome-history");

function mockChrome(items, lastError = null) {
  return {
    runtime: { lastError },
    history: {
      search(options, callback) {
        mockChrome.lastOptions = options;
        callback(items);
      }
    }
  };
}

test("Chrome History APIの結果を検索語に正規化", async () => {
  const chrome = mockChrome([{
    id: "1", url: "https://www.google.com/search?q=JavaScript",
    lastVisitTime: Date.parse("2026-01-01T00:00:00Z")
  }]);
  const adapter = createChromeHistoryAdapter(chrome);
  const rows = await adapter.getSearchHistory();
  assert.equal(rows[0].keyword, "JavaScript");
  assert.equal(rows[0].source, "chrome");
});
test("指定期間と件数をAPIに渡す", async () => {
  const chrome = mockChrome([]);
  const adapter = createChromeHistoryAdapter(chrome);
  await adapter.getSearchHistory({ startTime: 10, endTime: 20, maxResults: 50 });
  assert.equal(mockChrome.lastOptions.startTime, 10);
  assert.equal(mockChrome.lastOptions.maxResults, 50);
});
test("API未提供を拒否", () => {
  assert.throws(() => createChromeHistoryAdapter({}), /利用できません/);
});
test("逆転した期間を拒否", async () => {
  const adapter = createChromeHistoryAdapter(mockChrome([]));
  await assert.rejects(adapter.getSearchHistory({ startTime: 20, endTime: 10 }), /期間/);
});
test("上限を超えるmaxResultsを拒否", async () => {
  const adapter = createChromeHistoryAdapter(mockChrome([]));
  await assert.rejects(adapter.getSearchHistory({ maxResults: 10001 }), /maxResults/);
});
test("Chrome APIエラーを伝播", async () => {
  const chrome = mockChrome([], { message: "permission denied" });
  const adapter = createChromeHistoryAdapter(chrome);
  await assert.rejects(adapter.getSearchHistory(), /permission denied/);
});
