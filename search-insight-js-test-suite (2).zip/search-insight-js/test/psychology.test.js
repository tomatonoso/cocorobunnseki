const test = require("node:test");
const assert = require("node:assert/strict");
const { generatePsychologicalHypotheses } = require("../src/psychology");

test("空履歴では仮説を生成しない", () => {
  assert.deepEqual(generatePsychologicalHypotheses([]), []);
});
test("比較検索から情報収集傾向の仮説を生成", () => {
  const result = generatePsychologicalHypotheses([{ keyword: "商品 比較 おすすめ" }]);
  assert.ok(result.some(item => item.id === "information_seeking"));
});
test("方法検索から課題解決傾向の仮説を生成", () => {
  const result = generatePsychologicalHypotheses([{ keyword: "問題 解決 方法" }]);
  assert.ok(result.some(item => item.id === "problem_solving"));
});
test("将来準備の仮説に別解釈を含める", () => {
  const result = generatePsychologicalHypotheses([{ keyword: "将来の計画" }]);
  const item = result.find(x => x.id === "future_planning");
  assert.ok(item);
  assert.ok(item.alternativeInterpretation);
});
test("すべての仮説に断定回避の注意書きがある", () => {
  const result = generatePsychologicalHypotheses([{ keyword: "不安 大丈夫 安全" }]);
  for (const item of result) {
    assert.match(item.disclaimer, /断定|確定/);
    assert.ok(["低め", "中程度"].includes(item.confidence));
  }
});
test("少数の一致で高確信度を出さない", () => {
  const result = generatePsychologicalHypotheses([{ keyword: "不安" }]);
  assert.equal(result[0].confidence, "低め");
});
test("心理診断を返すフィールドを持たない", () => {
  const result = generatePsychologicalHypotheses([{ keyword: "心配 方法" }]);
  for (const item of result) {
    assert.equal(Object.hasOwn(item, "diagnosis"), false);
  }
});
