const test = require("node:test");
const assert = require("node:assert/strict");
const { InMemoryHistoryStore, ConsentRequiredError } = require("../src/privacy-store");

test("同意なしの保存を拒否", () => {
  const store = new InMemoryHistoryStore();
  assert.throws(() => store.save("user-a", []), ConsentRequiredError);
});
test("同意後に保存・読取できる", () => {
  const store = new InMemoryHistoryStore();
  store.grantConsent("user-a");
  store.save("user-a", [{ keyword: "検索" }]);
  assert.equal(store.read("user-a").length, 1);
});
test("ユーザー間でデータを分離", () => {
  const store = new InMemoryHistoryStore();
  store.grantConsent("a");
  store.grantConsent("b");
  store.save("a", [{ keyword: "A" }]);
  store.save("b", [{ keyword: "B" }]);
  assert.equal(store.read("a")[0].keyword, "A");
  assert.equal(store.read("b")[0].keyword, "B");
});
test("同意撤回後の読取を拒否", () => {
  const store = new InMemoryHistoryStore();
  store.grantConsent("a");
  store.revokeConsent("a");
  assert.throws(() => store.read("a"), ConsentRequiredError);
});
test("削除すると履歴と同意状態を削除", () => {
  const store = new InMemoryHistoryStore();
  store.grantConsent("a");
  store.save("a", [{ keyword: "秘密ではないテストデータ" }]);
  store.deleteAll("a");
  assert.throws(() => store.read("a"), ConsentRequiredError);
});
test("userIdなしの同意付与を拒否", () => {
  const store = new InMemoryHistoryStore();
  assert.throws(() => store.grantConsent(""), /userId/);
});
